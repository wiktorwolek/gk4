﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Projekt4
{
    public class Obj
    {
        public string name;
        public List<Vector4> points;
        public List<Vector3> normalVector;

        public List<Vector3> normalPoints;

        public List<(int[], int[])> faces;
        public Matrix4x4 modelMatrix = Matrix4x4.Identity;
        public Color color;

        static Random random = new Random();

        public Obj(string filePath)
        {
            loadFile(filePath);
            switch (random.Next(0, 3))
            {
                case 0: 
                    color = Color.Green;
                    break;
                    case 1:
                    color = Color.Blue;
                    break;
                    case 2:
                    color = Color.Red;
                    break;
                case 3:
                    color = Color.Magenta;
                    break;
                default:
                    throw new Exception();
            }
        }

        private void loadFile(string filePath)
        {
            points = new List<Vector4>();
            normalVector = new List<Vector3>();
            normalPoints = new List<Vector3>();
            List<List<Vector3>> tmpNorm = new List<List<Vector3>>();    
            faces = new List<(int[], int[])>();

            float maxCoord = 0.0f;

            foreach (string line in System.IO.File.ReadLines(filePath))
            {
                if (line.Count() == 0 || line.First() == '#') continue;
                string[] args = line.Split(" ").Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
                switch (args[0])
                {
                    case "o":
                        {
                            name = args[1];
                            break;
                        }
                    case "v":
                        {
                            Vector4 v = new Vector4(float.Parse(args[1], CultureInfo.InvariantCulture), float.Parse(args[2], CultureInfo.InvariantCulture), float.Parse(args[3], CultureInfo.InvariantCulture), 1.0f);
                            checkMax(v, ref maxCoord);
                            points.Add(v);
                            tmpNorm.Add(new List<Vector3>());
                            break;
                        }
                    case "vn":
                        {
                            Vector3 vn = new Vector3(float.Parse(args[1], CultureInfo.InvariantCulture), float.Parse(args[2], CultureInfo.InvariantCulture), float.Parse(args[3], CultureInfo.InvariantCulture));
                            vn = Vector3.Normalize(vn);
                            normalVector.Add(vn);
                            break;
                        }
                    case "f":
                        {
                            (int[], int[]) tmp = (new int[args.Length - 1], new int[args.Length - 1]);
                            for (int i = 1; i < args.Length; i++)
                            {
                                string[] indices = args[i].Split("/");
                                tmp.Item1[i - 1] = int.Parse(indices[0]) - 1;
                                tmp.Item2[i - 1] = int.Parse(indices[2]) - 1;
                                tmpNorm[tmp.Item1[i - 1]].Add(normalVector[tmp.Item2[i - 1]]);
                        }
                        faces.Add(tmp);
                        break;
                }
            }
        }
            foreach(var e in tmpNorm)
            {
                Vector3 n = new Vector3();
                foreach(var i in e)
                {
                    n += i;
                }
                n = n / e.Count;
                n = Vector3.Normalize(n);
                normalPoints.Add(n);
            }
        points = points.Select(v => rescale(0.9f / maxCoord, v)).ToList();
    }

    private void checkMax(Vector4 v, ref float maxCoord)
    {
        float max = 0.0f;
        max = Math.Max(max, v.X);
        max = Math.Max(max, v.Y);
        max = Math.Max(max, v.Z);
        maxCoord = Math.Max(maxCoord, max);
    }

    private Vector4 rescale(float alpha, Vector4 vec)
    {
        vec.X *= alpha;
        vec.Y *= alpha;
        vec.Z *= alpha;
        return vec;
    }
}
}

